<?php
// Heading
$_['heading_title'] = 'Bestsellers';

// Text
$_['text_tax']      = 'Ex Tax:';
$_['text_days']     = 'Days';
$_['text_hours']    = 'Hours';
$_['text_minutes']  = 'Min';
$_['text_seconds']  = 'Sec';
$_['text_expired']  = 'Expired';
$_['product_unavailable']     = 'unavailable';
$_['product_available']     = 'available';