<?php
// Heading
$_['Menu_heading_title'] = 'Shop Categories';
$_['text_blog']          = 'Blogs';