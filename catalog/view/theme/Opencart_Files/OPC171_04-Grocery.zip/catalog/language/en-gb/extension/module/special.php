<?php
// Heading
$_['heading_title3'] = 'Specials';

// Text
$_['text_tax']      = 'Ex Tax:';