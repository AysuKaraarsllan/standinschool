<?php
// Heading
$_['heading_title1'] = 'Featured';

// Text
$_['text_tax']      = 'Ex Tax:';