<?php
// Heading
$_['heading_title2'] = 'Categories';