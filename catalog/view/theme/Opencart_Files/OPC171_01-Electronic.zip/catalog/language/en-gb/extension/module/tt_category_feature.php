<?php
// Heading
$_['heading_title1'] = 'Category Feature';

// Text
$_['text_tax']      = 'Ex Tax:';