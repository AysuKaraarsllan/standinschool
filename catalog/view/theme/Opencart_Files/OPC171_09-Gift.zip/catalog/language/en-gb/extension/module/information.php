<?php
// Heading
$_['heading_title3'] = 'Information';

// Text
$_['text_contact']  = 'Contact Us';
$_['text_sitemap']  = 'Site Map';