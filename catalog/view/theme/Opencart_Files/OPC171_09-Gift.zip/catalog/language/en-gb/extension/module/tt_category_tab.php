<?php
// Heading
$_['cat_heading_title'] = 'Top categories';