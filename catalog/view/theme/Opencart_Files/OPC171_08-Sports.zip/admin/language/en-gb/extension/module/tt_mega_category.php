<?php
// Heading
$_['heading_title']    = '<font color="#F64444">TT Mega Category</font>';

$_['text_extension']   = 'Extensions';
$_['text_module']      = 'Modules';
$_['text_success']     = 'Success: You have modified TT Mega Category module!';
$_['text_edit']        = 'Edit TT Mega Category Module';

// Entry
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify TT Mega Category module!';