<?php
// Heading 
$_['heading_title']		= 'Latest News';

$_['text_read_more']	= 'read more';
$_['text_date_added']	= 'Date Added:';
$_['entry_comment']		= 'Comments';

$_['button_all_blogs'] = 'See all blogs';